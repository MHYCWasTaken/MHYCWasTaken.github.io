# MINECRAFT NEVER DIE!
### MHYC likes Minecraft!

我的世界，Minecraft。

Now by Mojang AB Microsoft.（MHYC has no relationship with them）

我的世界的魅力在于，你越用脑子，他就越好玩；越不用脑子，他就越无聊

MHYC的我的世界Blog:

[MC入坑指南](./minecraft/mc_starter.md)

[Minecraft服务器开设指南](./minecraft/mc_server.md)