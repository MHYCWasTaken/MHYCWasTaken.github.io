# Welcome to MHYC Blog!

All of the Blogs are in Chinese.(?)

Goto [github](https://github.com/MHYCWasTaken/MHYCWasTaken.github.io) to see github files.

### HAPPY BIRTHDAY DADDY!
[happy birthday!11.26](./happybirthday.md)

### Diary
Most of them are about study...
[link](./posts/study_index.md)

### UndetectedLand!
emm... It's a minecrfat mod but still in alpha version.

### R.I.P.

For my second granpa and my dog, Lucky.

[Here's](./posts/rip_photo.md) Theirs Photos

### Blogs

[Minecraft](./posts/minecraft_index.md)

[c++](./posts/cpp_index.md)

[HTML](./posts/html_indx.md)

[Java](./posts/java_index.md)

### Bilibili

Goto [Bilibili](https://space.bilibili.com/1251782597) and sub me

### Contract MHYC

Use Wechat: MHYC133

Use E-Mail: MHYC133@outlook.com

Or just simply go to bilibili.
